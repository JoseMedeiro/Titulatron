
function D = DIST_ABS(A, B)
    D = abs(A - B);
end