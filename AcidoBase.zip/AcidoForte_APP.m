%   Funcao de Acido Forte
%%  INPUT
%
%   app         - dados da aplicacao
%   OHInicial   - OH inicial                        (mol/l)
%   H3OInicial  - H3O inicial                       (mol/l)
%   KH2O        - Constante de ionização da água
%
%%  OPERACAO
%
%   Resgata de app
%       KH2O        - Constante de ionizacao da agua
%   Realiza o metodo da bissecao a equacao de equilibrio da agua para
%   encontrar o incremento y
%
%%  DEPENDENCIAS
%
%   Cancelar
%
%%  OUTPUT
%   
%   D - valor do incremento y                       (mol/l)
%
%%  NOTAS
%
%   QUIM
%       QUIM (1, :) - Incremento de OH = incremento de H3O
%       QUIM (2, :) - Erro da equacao com os valores supramencionados
%
%%
function D = AcidoForte_APP(app, OHInicial, H3OInicial)

    % Preparacao dos dados
    KH2O = app.KH2O
    QUIM        = zeros(2,2);
    QUIM_Meio   = zeros(2,1);
    COUNTER     = 0;
    %   Fase Inicial
    if OHInicial < H3OInicial
        QUIM(1,:) = [-OHInicial 0];
    else
        QUIM(1,:) = [-H3OInicial 0];
    end

    QUIM(2,:) = (QUIM(1,:) + H3OInicial).*(QUIM(1,:) + OHInicial)/KH2O - 1;

    FLAG = 2;
    %   Ciclo para encontrar uma solução
    while (DIST_ABS(QUIM(1,1),QUIM(1,2)) > 10^(-14))&&...
           COUNTER < 400

        QUIM_Meio(1) = (QUIM(1,1)+QUIM(1,2))/2;
        QUIM_Meio(2) = (QUIM_Meio(1) + H3OInicial)*(QUIM_Meio(1) + OHInicial)/KH2O - 1;

        QUIM = Bissecao_APP(QUIM, QUIM_Meio);
        %   LOOP COUNTER
        COUNTER = COUNTER+1;
    end

    if (Cancelar(app)==0)
        FLAG = 1;
    end

    D = QUIM(1:(size(QUIM,1)-1), FLAG);

end
