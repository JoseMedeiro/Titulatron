%   Funcao de Acido Fraco
%%  INPUT
%
%   app         - dados da aplicacao
%   OHInicial   - OH inicial                        (mol/l)
%   H3OInicial  - H3O inicial                       (mol/l)
%   RHInicial   - Ácido não ionizado inicial        (mol/l)
%   RInicial    - Ácido ionizado inicial            (mol/l)
%
%%  OPERACAO
%
%   Resgata de app
%       k1          - Constante de ionizacao do acido
%   Realiza o metodo da bissecao em R2:
%   Realiza o metodo da bissecao a equacao de equilibrio do acido fraco com
%   o incremento y obtido atraves do metodo da bissecao para os valores w
%   estipulados (atraves da função AcidoForteEX)
%
%%  DEPENDENCIAS
%
%   AcidoForte_APP
%   Cancelar
%
%%  OUTPUT
%   
%   D - vetor linha com o valor do incremento y e do incremento w,
%   respetivamente                                  (mol/l)
%
%%  NOTAS
%
%   QUIM
%       QUIM (1, :) - Incremento em R (eq.1)
%       QUIM (2, :) - Incremento em H3O (eq.2)
%       QUIM (3, :) - Erro da equacao com os valores supramencionados
%
%%
function D = AcidoFraco_APP(app, OHInicial, H3OInicial, RHInicial, RInicial)

    % Preparacao dos dados
    k1 = app.K1.Value;
    kH2O = app.KH2O;
    QUIM        = zeros(3,2);
    QUIM_Meio   = zeros(3,1);
    COUNTER     = 0;
    %   Fase Inicial
    QUIM(1,:) = [-RInicial+2^(-26) RHInicial-2^(-26)];

    QUIM(2,1) = AcidoForte_APP(app, OHInicial, H3OInicial+QUIM(1,1));
    QUIM(2,2) = AcidoForte_APP(app, OHInicial, H3OInicial+QUIM(1,2));

    QUIM(3,:) = (QUIM(1,:)+RInicial).*(QUIM(1,:) + QUIM(2,:) + H3OInicial)./(k1*(RHInicial-QUIM(1,:))) - 1;
    FLAG = 2;

    %   Ciclo para encontrar uma solução
    while (((DIST_ABS(QUIM(2,1),QUIM(2,2)) > 10^(-14))&&(DIST_REL(QUIM(2,1),QUIM(2,2)) > 10^(-6)))  ||...
           ((DIST_ABS(QUIM(1,1),QUIM(1,2)) > 10^( -8))&&(DIST_REL(QUIM(1,1),QUIM(1,2)) > 10^(-6)))) &&...
             Cancelar(app)                                                                          &&...
             COUNTER < 400

        QUIM_Meio(1) = (QUIM(1,1)+QUIM(1,2))/2;
        QUIM_Meio(2) = AcidoForte_APP(app, OHInicial, H3OInicial+QUIM_Meio(1));
        QUIM_Meio(3) = (QUIM_Meio(1)+RInicial).*(QUIM_Meio(1) + QUIM_Meio(2) + H3OInicial)./(k1*(RHInicial-QUIM_Meio(1))) - 1;
        QUIM = Bissecao_APP(QUIM, QUIM_Meio);
        %   LOOP COUNTER
        COUNTER = COUNTER + 1;
    end

    if (Cancelar(app)==0)
        FLAG = 1;
    end

    D = QUIM(1:(size(QUIM,1)-1), FLAG);

end