%   Função de Ácido Fraco
%%  INPUT
%
%   OHInicial   - OH inicial                        (mol/l)
%   H3OInicial  - H3O inicial                       (mol/l)
%   RHInicial   - Ácido não ionizado inicial        (mol/l)
%   RInicial    - Ácido ionizado inicial            (mol/l)
%   k1          - Constante de ionização do ácido
%   KH2O        - Constante de ionização da água
%
%%  OPERAÇÃO
%
%   Realiza o método da bisseção em R2:
%   Realiza o método da bisseção à equação de equilíbrio do ácido fraco com
%   o incremento y obtido através do método da bisseção para os valores w
%   estipulados (através da função AcidoForteEX)
%
%%  DEPENDÊNCIAS
%
%   AcidoForteEX
%
%%  OUTPUT
%   
%   D - vetor linha com o valor do incremento y e do incremento w,
%   respetivamente                                  (mol/l)
%
%%
function D = COMP_AcidoFraco_APP(app, QuantidadeInicial)
            
            ponto_titulacao = Ponto_Equilibrio_Simples(app);
            a = size(ponto_titulacao,2);
            
            z  = 0:(ponto_titulacao(a)*(1+1/a))/(10^(4)):ponto_titulacao(a)*(1+1/a);
            Volume = Volume_Inicial(app) + z;
            Titulante = z*Concentracao_Titulante(app);
            
            ph = zeros(size(z));
            RH = zeros(size(z));
            R  = zeros(size(z));
            
            OHInicial = 10^(-7);
            H3OInicial = 10^(-7);
            
            for c = 1:size(z,2)
                if ~Cancelar(app)
                    break;
                end
                OH          = OHInicial  + Titulante(c)/Volume(c);
                H3O         = H3OInicial;
                RHInicial   = QuantidadeInicial/Volume(c);
                
                y = AcidoFraco_APP(app, OH, H3O, RHInicial, 0);
                
                ph(c) = -log(H3O+y(1)+y(2))/log(10);
                RH(c) = RHInicial-y(1);
                R(c)  = y(1);
                
                app.Percentagem.Value = c/size(z,2)*100;
                drawnow;
                
            end
            if strcmp(app.TitulanteSwitch.Value,'Base')
                D = [z; ph; R; RH];
            else
                D = [z; 14-ph; R; RH];
            end
            
        end