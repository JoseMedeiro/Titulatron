%   Funcao de Acido Diprotico
%%  INPUT
%
%   app         - dados da aplicacao
%   OHInicial   - OH inicial                        (mol/l)
%   H3OInicial  - H3O inicial                       (mol/l)
%   RHInicial   - Ácido não ionizado inicial        (mol/l)
%   RInicial    - Ácido ionizado inicial            (mol/l)
%
%%  OPERACAO
%
%   Resgata de app
%       k2          - Constante de ionizacao do acido
%   Realiza o metodo da bisseção em R2:
%   Realiza o metodo da bissecao a equacao de equilibrio do acido fraco com
%   o incremento y obtido atraves do metodo da bissecao para os valores w
%   estipulados (atraves da função AcidoFraco_APP)
%
%%  DEPENDENCIAS
%
%   AcidoFraco_APP
%   Cancelar
%
%%  OUTPUT
%   
%   D - vetor linha com o valor do incremento y e do incremento w,
%   respetivamente                                  (mol/l)
%
%%  NOTAS
%
%   QUIM
%       QUIM (1, :) - Incremento em RH                              (eq.1)
%       QUIM (2, :) - Incremento em R                               (eq.2)
%       QUIM (3, :) - Incremento em H3O                             (eq.3)
%       QUIM (4, :) - Erro da equacao com os valores supramencionados
%
%%
function D = AcidoDiprotico_APP(app, OHInicial, H3OInicial, RH2Inicial, RHInicial)
    
    % Preparacao dos dados
    k2 = app.K2.Value;
    QUIM        = zeros(4,2);
    QUIM_Meio   = zeros(4,1);
    COUNTER     = 0;
    FLAG = 2;
    %   Fase Inicial
    QUIM(2,:)   = [0 RH2Inicial-2^(-25)];
    HOLD        = AcidoFraco_APP(app, OHInicial, H3OInicial+QUIM(2,1), RH2Inicial, -QUIM(2,1));
    QUIM(1,1)   = HOLD(1);
    QUIM(3,1)   = HOLD(2);
    HOLD        = AcidoFraco_APP(app, OHInicial, H3OInicial+QUIM(2,2), RH2Inicial, -QUIM(2,2));
    QUIM(1,2)   = HOLD(1);
    QUIM(3,2)   = HOLD(2);
    QUIM(4,:)   = (QUIM(2,:)).*(QUIM(1,:) + QUIM(2,:) + QUIM(3,:) + H3OInicial)...
                ./(k2*(QUIM(1,:) - QUIM(2,:))) - 1;

    %   Ciclo para encontrar uma solução
    while (((DIST_ABS(QUIM(3,1),QUIM(3,2)) > 10^(-14))&&(DIST_REL(QUIM(3,1),QUIM(3,2)) > 10^(-5))) ||...
           ((DIST_ABS(QUIM(2,1),QUIM(2,2)) > 10^(-14))&&(DIST_REL(QUIM(2,1),QUIM(2,2)) > 10^(-5))) ||...
           ((DIST_ABS(QUIM(1,1),QUIM(1,2)) > 10^( -8))&&(DIST_REL(QUIM(1,1),QUIM(1,2)) > 10^(-3))))&&...
            Cancelar(app)                                                                          &&...
            COUNTER < 400

        QUIM_Meio(2)    = (QUIM(2,1)+QUIM(2,2))/2;
        HOLD            = AcidoFraco_APP(app, OHInicial, H3OInicial+QUIM_Meio(2), RH2Inicial, -QUIM_Meio(2));
        QUIM_Meio(1)    = HOLD(1);
        QUIM_Meio(3)    = HOLD(2);
        QUIM_Meio(4)    = (QUIM_Meio(2))*(QUIM_Meio(1) + QUIM_Meio(2) + QUIM_Meio(3) + H3OInicial)...
                         /(k2*(QUIM_Meio(1) - QUIM_Meio(2))) - 1;
            
        QUIM = Bissecao_APP(QUIM, QUIM_Meio);
        %   LOOP COUNTER
        COUNTER = COUNTER + 1;
    end

    if (Cancelar(app)==0)
        FLAG = 1;
    end

    D = QUIM(1:(size(QUIM,1)-1), FLAG);

end